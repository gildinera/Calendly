<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TicTacToe Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>1a6c21f6-7f44-4c05-8a2e-2325a92789f1</testSuiteGuid>
   <testCaseLink>
      <guid>11636fd8-6c63-4623-b448-53e2e3aead82</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Create 3x3 Game</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>581729eb-65c7-47c4-b867-383276e91dfc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Create 4x4 Game</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>dd5f8fbc-0e88-4283-bddd-d1026da39a47</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/3x3 Game - O Wins</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>20876356-54e6-45c0-8a04-67788cf68d28</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/3x3 Game - X Wins</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>51808e41-a1cb-4929-8430-2b2cb4503aef</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Win Game - Refresh - New Game</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
